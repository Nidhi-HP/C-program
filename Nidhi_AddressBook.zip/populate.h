void populateAddressBook(AddressBook* addressBook);
